package com.app.pojos;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "copies")
public class Copy 
{
	private Integer id;
	private Integer rack;
	private CopyStatus status;
	private Book bkid;
	@JsonIgnore
	private IssueRecord recId;
	public Copy() {
		System.out.println("in Copy ctor");
	}
	public Copy(Integer rack, CopyStatus status, Book bkid) {
		super();
		this.rack = rack;
		this.status = status;
		this.bkid = bkid;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getRack() {
		return rack;
	}
	public void setRack(Integer rack) {
		this.rack = rack;
	}
	@Enumerated(EnumType.STRING)
	public CopyStatus getStatus() {
		return status;
	}
	public void setStatus(CopyStatus status) {
		this.status = status;
	}
	@ManyToOne
	@JoinColumn(name = "bk_id")
	public Book getBkid() {
		return bkid;
	}
	public void setBkid(Book bkid) {
		this.bkid = bkid;
	}
	@OneToOne(mappedBy = "cpId",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	public IssueRecord getRecId() {
		return recId;
	}
	public void setRecId(IssueRecord recId) {
		this.recId = recId;
	}
	
	
}
