package com.app.pojos;

public enum CopyStatus 
{
	A,NA
}
