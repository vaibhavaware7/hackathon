package com.app.daos;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Book;
import com.app.pojos.User;

@Repository
@Transactional
public class UserDao implements IUserDao 
{
	@Autowired
	private SessionFactory sf;
	
	@Override
	public User validatUser(String email, String pass) {
		
		String jpql = "select u from User u where u.email=:em and u.password=:pass";
		return sf.getCurrentSession().createQuery(jpql, User.class).setParameter("em",email)
				.setParameter("pass",pass).getSingleResult();
	}

	@Override
	public User changePassword(String email, String password, String newPassword) {
		String jpql="select u from User u where u.email=:em and u.password=:pass";
		User user = sf.getCurrentSession().createQuery(jpql, User.class).setParameter("em",email).setParameter("pass", password).getSingleResult();
		user.setPassword(newPassword);
		sf.getCurrentSession().update(user);
		return user;
	}

	@Override
	public Book findBook(String bookname) 
	{
		String jpql="select b from Book b where b.name=:nm";
		
		return sf.getCurrentSession().createQuery(jpql, Book.class).setParameter("nm",bookname).getSingleResult();
	}

}
