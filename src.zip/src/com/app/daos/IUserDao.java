package com.app.daos;

import com.app.pojos.Book;
import com.app.pojos.User;

public interface IUserDao 
{
	User validatUser(String email,String pass);

	User changePassword(String email, String password, String newPassword);

	Book findBook(String bookname);
}
