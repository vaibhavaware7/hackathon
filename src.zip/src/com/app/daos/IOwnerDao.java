package com.app.daos;

import com.app.pojos.User;

public interface IOwnerDao 
{
	public void changePassword(String email,String pass);
	public User editUser(int user_id, User u);
}
