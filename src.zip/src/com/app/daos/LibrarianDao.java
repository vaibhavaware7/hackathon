package com.app.daos;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Book;
import com.app.pojos.Copy;
import com.app.pojos.CopyStatus;
import com.app.pojos.Payments;
import com.app.pojos.Ptype;
import com.app.pojos.User;

@Repository
@Transactional
public class LibrarianDao implements ILibrarian 
{
	@Autowired
	private SessionFactory sf;

	@Override
	public List<User> listAllUser()
	{
		String jpql="select u from User u";
		return sf.getCurrentSession().createQuery(jpql, User.class).getResultList();
	}

	@Override
	public void makePayment(Integer id, Double amount) 
	{
		String jpql="insert into Payments p (p.amount,p.type,p.transTime,p.nextpayment_duedate,p.payId) "
				+ "values(:amt,:type,:ti,:date,:id)";
		sf.getCurrentSession().createQuery(jpql, Payments.class).setParameter("amt",amount).
				setParameter("type",Ptype.CASH).setParameter("ti",LocalDateTime.now()).
				setParameter("date", LocalDateTime.now()).setParameter("id", id).executeUpdate();
		
	}

	@Override
	public void addCopy(Integer bkid, Integer rackid) 
	{
		String jpql = "insert into Copy c (c.id,c.rack,c.status,c.bkid) values(default,:rk,:st,:id)";
		sf.getCurrentSession().createQuery(jpql, Copy.class).setParameter("rk",rackid).
		setParameter("st", CopyStatus.A).setParameter("id",bkid).executeUpdate();
	}

	@Override
	public void addBook(Book b)
	{
		sf.getCurrentSession().persist(b);
	}

	@Override
	public void issueBook(Book b)
	{
		
	}
	
	@Override
	public User editUser(Integer id,User u) 
	{
		User user = sf.getCurrentSession().get(User.class,id);
		user.setEmail(u.getEmail());
		user.setName(u.getName());
		user.setPassword(u.getPassword());
		user.setPhone(u.getPhone());
		sf.getCurrentSession().update(user);
		return user;
	}

	@Override
	public User addUser(User u) {
		sf.getCurrentSession().persist(u);
		return u;
	}

	@Override
	public List<Copy> bookAvailability(int id) 
	{
		String jpql="Select c from Copy c where c.id=:id";
		List<Copy> resultList = sf.getCurrentSession().createQuery(jpql, Copy.class).setParameter("id", id).getResultList();
		return resultList;
	}

	@Override
	public void changePassword(String email, String pass) 
	{
		String jpql="Select u from User u where u.email=:email";
		User u=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("email", email).getSingleResult();
		u.setPassword(pass);
		sf.getCurrentSession().update(u);
	}

	@Override
	public List<Book> findBook(String name) 
	{
		String jpql="select b from Book b where b.name=:na";
		List<Book> resultList = sf.getCurrentSession().createQuery(jpql, Book.class).setParameter("na", name).getResultList();
		return resultList;
	}
}
