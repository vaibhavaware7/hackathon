package com.app.daos;

import java.util.List;

import com.app.pojos.Book;
import com.app.pojos.Copy;
import com.app.pojos.User;

public interface ILibrarian 
{
	List<User> listAllUser();

	void makePayment(Integer id, Double amount);

	void addCopy(Integer bkid, Integer rackid);

	void addBook(Book b);

	void issueBook(Book b);
	public User editUser(Integer id,User u);
	public User addUser(User u);
	public List<Copy> bookAvailability(int id);
	public void changePassword(String email,String pass);
	public List<Book> findBook(String name);
	
}
