package com.app.daos;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.User;

@Repository
@Transactional
public class OwnerDao implements IOwnerDao 
{
	@Autowired
	SessionFactory sf;
	@Override
	public void changePassword(String email, String pass)
	{
		String jpql="Select * from User u where u.email=:email";
		User u=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("email", email).getSingleResult();
		u.setPassword(pass);
		sf.getCurrentSession().update(u);
	}

	@Override
	public User editUser(int id,User u) 
	{	User user = sf.getCurrentSession().get(User.class,id);
	user.setEmail(u.getEmail());
	user.setName(u.getName());
	user.setPassword(u.getPassword());
	user.setPhone(u.getPhone());
	sf.getCurrentSession().update(user);
	return user;
	}
   
}
