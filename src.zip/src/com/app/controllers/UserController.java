package com.app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.daos.IUserDao;
import com.app.pojos.Book;
import com.app.pojos.User;

@RestController
@RequestMapping("/users")
public class UserController 
{
	@Autowired
	private IUserDao dao;
	
	@PostMapping("/login")
	public ResponseEntity<?> validate(@RequestBody User u)
	{
		System.out.println(u.getEmail() + " "+ u.getPassword());
		User user = dao.validatUser(u.getEmail(),u.getPassword());
		if(user != null)
			return new ResponseEntity<User>(user, HttpStatus.OK);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);			
			
		
	}
	@GetMapping("/chpa")
	public ResponseEntity<?> changePassword(@RequestParam String email,@RequestParam String password,@RequestParam String newPassword)
	{
		User user = dao.changePassword(email, password,newPassword);
		if(user != null)
			return new ResponseEntity<User>(user, HttpStatus.OK);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);			
	}
	@PostMapping("/edit")
	public ResponseEntity<?> editProfile(@RequestParam String email,@RequestParam String password,@RequestParam String newPassword )
	{
		User user;
		try {
			user = dao.changePassword(email, password,newPassword);
			return new ResponseEntity<User>(user, HttpStatus.OK);
			
		} catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);			
			
		}
	}
	@GetMapping("/find/{bookname}")
	public ResponseEntity<?> findBook(@PathVariable String bookname)
	{
		System.out.println("bookname"+bookname);
		Book book = dao.findBook(bookname);
		if(book != null)
		{
			return new ResponseEntity<Book>(book, HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}	

