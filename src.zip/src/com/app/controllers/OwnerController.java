package com.app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.daos.IOwnerDao;
import com.app.pojos.User;

@RestController
@RequestMapping("/owner")
public class OwnerController 
{
	@Autowired
	IOwnerDao dao;
	
	@PostMapping("/{user_id}")
	public ResponseEntity<?> editUser(@PathVariable int user_id,@RequestBody User u)
	{
		System.out.println("in edit user");
		User editUser = dao.editUser(user_id,u);
		if(editUser!=null)
			return new ResponseEntity<User>(u,HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	@PostMapping("/changePassword")
	public ResponseEntity<?> changePass(@RequestBody String email,@RequestBody String newpass)
	{
		System.out.println("in change Password");
		try
		{
			dao.changePassword(email, newpass);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e)
		{
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE);
		}
	}

}
