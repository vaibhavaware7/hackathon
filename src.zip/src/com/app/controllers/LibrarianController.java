package com.app.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.daos.ILibrarian;
import com.app.pojos.Book;
import com.app.pojos.Copy;
import com.app.pojos.User;

@RestController
@RequestMapping("/lib")
public class LibrarianController
{
	@Autowired
	private ILibrarian dao;
	
	@PostMapping("/{user_id}")
	public ResponseEntity<?> editUser(@PathVariable int user_id,@RequestBody User u)
	{
		System.out.println("in edit user");
		User editUser = dao.editUser(user_id,u);
		if(editUser!=null)
			return new ResponseEntity<User>(u,HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	@PostMapping("/add")
	public ResponseEntity<?> addUser(@RequestBody User u)
	{
		System.out.println("in add user");
		User addUser = dao.addUser(u);
		if(addUser!=null)
			return new ResponseEntity<User>(u,HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	@GetMapping("/books/{book_id}")
	public ResponseEntity<?> bookAvailability(@PathVariable int book_id)
	{
		System.out.println("in book availability");
		List<Copy> l=dao.bookAvailability(book_id);
		if(!l.isEmpty())
			return new ResponseEntity<List<Copy>>(l,HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	@PostMapping("/changePassword")
	public ResponseEntity<?> changePass(@RequestBody String email,@RequestBody String newpass)
	{
		System.out.println("in change Password");
		try
		{
			dao.changePassword(email, newpass);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e)
		{
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE);
		}
	}
	@GetMapping("/booksbyname/{name}")
	public ResponseEntity<?> findBook(@PathVariable String name)
	{
		System.out.println("in find book");
		List<Book> findBook = dao.findBook(name);
		if(!findBook.isEmpty())
			return new ResponseEntity<List<Book>>(findBook,HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/users")
	public ResponseEntity<?> listAllUsers()
	{
		List<User> list = dao.listAllUser();
		if(list != null)
			return new ResponseEntity<List<User>>(list, HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	@GetMapping("/pay")
	public ResponseEntity<?> makePayment(@RequestParam Integer id,@RequestParam Double amount)
	{
		try {
			dao.makePayment(id,amount);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	@GetMapping("/add")
	public ResponseEntity<?> addCopy(@RequestParam Integer bkid,@RequestParam Integer rackid)
	{
		try {
			dao.addCopy(bkid,rackid);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	@PostMapping("/addbk")
	public ResponseEntity<?> addBook(@RequestBody Book b)
	{
		try {
			dao.addBook(b);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	/*
	 * @PostMapping("/issue") public ResponseEntity<?> issueBook(@RequestBody Book
	 * b,) { try { dao.issueBook(b); return new ResponseEntity<>(HttpStatus.OK); }
	 * catch(Exception e) { e.printStackTrace(); return new
	 * ResponseEntity<>(HttpStatus.NO_CONTENT); } }
	 */
	
	
	
	
}
