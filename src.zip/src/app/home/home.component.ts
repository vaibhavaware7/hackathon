import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
//import { request } from 'http';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  emps: any;

  constructor(private service: DataService,private service1:AuthService,
    public router: Router ) {

   }

  ngOnInit() {
    let observableResult = this.service.Select();
      observableResult.subscribe((result)=>{
        console.log(result);
        this.emps=result;
      });

   
    this.emps=[
      {"Name":"aditya","Email":"adi@gmail.com","Phone":8898989890,"Password":"adi","Role":"librarian"},
      {"Name":"aditya2","Email":"adi2@gmail.com","Phone":8898989891,"Password":"adi2","Role":"librarian"}
    ];

  }
  
  logout(){
    this.service1.SignOut();
    this.router.navigate(['login']);
  }
}
