import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-checkbook',
  templateUrl: './checkbook.component.html',
  styleUrls: ['./checkbook.component.css']
})
export class CheckbookComponent implements OnInit {

  copies={"Id":"","BookId":"","RackNo":"","Status":""}
  constructor(private route: ActivatedRoute,
    private router: Router,
    private service: DataService) { }
 
  ngOnInit() {
  }

  Search() {
    console.log(this.copies);
    let observableResult = this.service.SelectbyNo(this.copies);
    observableResult.subscribe((result) => {
      console.log(result);
      this.router.navigate(['/home']);
    });
  }

}
