import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent implements OnInit {

  emps:any;
  constructor(private service: DataService,private service1:AuthService,
    public router: Router ) { }

    ngOnInit()
     {
       debugger;
      let observableResult = this.service.Select();
      debugger;
        observableResult.subscribe((result)=>{
          console.log(result);
          this.emps=result;
          
        });
  
     
   
  
    }

  
}
