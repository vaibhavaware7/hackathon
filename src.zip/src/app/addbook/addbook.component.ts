import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {

  book={"name":"","author":"","subject":"","price":"","isbn":""}
  constructor(private route: ActivatedRoute,
    private router: Router,
    private service: DataService) { }
 
  ngOnInit() {
  }

  Insert() {
    console.log(this.book);
    let observableResult = this.service.Insert(this.book);
    observableResult.subscribe((result) => {
      console.log(result);
      this.router.navigate(['/home']);
    });
  }

}
