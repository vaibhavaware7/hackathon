package com.app.pojos;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "issuerecord")
public class IssueRecord 
{
	private Integer id;
	private Copy cpId;
	private User usrId;
	private Date issueDate;
	private Date returnDueDate;
	private Date returnDate;
	private Double fineAmount;
	public IssueRecord() 
	{
	System.out.println("in Issuerecord ctor");	// TODO Auto-generated constructor stub
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Copy getCpId() {
		return cpId;
	}

	public void setCpId(Copy cpId) {
		this.cpId = cpId;
	}

	public User getUsrId() {
		return usrId;
	}

	public void setUsrId(User usrId) {
		this.usrId = usrId;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public Date getReturnDueDate() {
		return returnDueDate;
	}

	public void setReturnDueDate(Date returnDueDate) {
		this.returnDueDate = returnDueDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public Double getFineAmount() {
		return fineAmount;
	}

	public void setFineAmount(Double fineAmount) {
		this.fineAmount = fineAmount;
	}

	public IssueRecord(Copy cpId, User usrId, Date issueDate, Date returnDueDate) {
		super();
		this.cpId = cpId;
		this.usrId = usrId;
		this.issueDate = issueDate;
		this.returnDueDate = returnDueDate;
	}
	
	
}
