package com.app.pojos;

public enum Role {
	USER,LIBRARIAN,OWNNER
}
