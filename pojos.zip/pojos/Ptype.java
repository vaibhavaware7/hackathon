package com.app.pojos;

public enum Ptype {
	CREDITCARD,DEBITCARD,CASH

}
